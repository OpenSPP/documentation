# Deduplication Manager

The deduplication manager allows to define how {term}`beneficiaries` are deduplicated within a program.
