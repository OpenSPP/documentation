# Licensing

OpenSPP is licensed as LGPL 3.0 and builds on top of other software with the following licensing:

- OpenG2P: GNU Lesser General Public License v3 (LPGLv3)
- Odoo: GNU Lesser General Public License v3 (LPGLv3)
