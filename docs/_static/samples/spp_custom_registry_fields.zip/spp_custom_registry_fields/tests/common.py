# Part of OpenSPP. See LICENSE file for full copyright and licensing details.
from odoo import Command
from odoo.tests.common import TransactionCase


class CustomFieldsTestCommon(TransactionCase):
    """Common test setup for spp_custom_registry_fields tests."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        # Create an "Education Level" vocabulary and codes
        cls.vocab_education = cls.env["spp.vocabulary"].create({
            "name": "Education Level",
        })

        cls.education_primary = cls.env["spp.vocabulary.code"].create({
            "vocabulary_id": cls.vocab_education.id,
            "name": "Primary",
        })

        cls.education_secondary = cls.env["spp.vocabulary.code"].create({
            "vocabulary_id": cls.vocab_education.id,
            "name": "Secondary",
        })

        cls.education_tertiary = cls.env["spp.vocabulary.code"].create({
            "vocabulary_id": cls.vocab_education.id,
            "name": "Tertiary",
        })

        # Create test users with different access levels
        base_user_group = cls.env.ref("base.group_user")

        cls.user_viewer = cls.env["res.users"].create({
            "name": "Registry Viewer",
            "login": "custom_fields_viewer",
            "email": "viewer@test.com",
            "group_ids": [
                Command.link(base_user_group.id),
                Command.link(
                    cls.env.ref(
                        "spp_custom_registry_fields.group_custom_fields_viewer"
                    ).id
                ),
            ],
        })

        cls.user_manager = cls.env["res.users"].create({
            "name": "Registry Manager",
            "login": "custom_fields_manager",
            "email": "manager@test.com",
            "group_ids": [
                Command.link(base_user_group.id),
                Command.link(
                    cls.env.ref(
                        "spp_custom_registry_fields.group_custom_fields_manager"
                    ).id
                ),
            ],
        })

    def _create_test_individual(self, **kwargs):
        """Create a test individual registrant.

        Args:
            **kwargs: Override default field values.

        Returns:
            res.partner: Created individual record.
        """
        default_vals = {
            "name": "Test Individual",
            "is_registrant": True,
            "is_group": False,
        }
        default_vals.update(kwargs)
        return self.env["res.partner"].create(default_vals)
