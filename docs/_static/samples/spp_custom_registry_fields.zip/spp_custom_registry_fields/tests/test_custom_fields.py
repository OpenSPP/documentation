# Part of OpenSPP. See LICENSE file for full copyright and licensing details.
from odoo.tests import tagged

from .common import CustomFieldsTestCommon


@tagged("post_install", "-at_install")
class TestCustomRegistryFields(CustomFieldsTestCommon):
    """Tests for custom registry fields on individual registrants."""

    def test_create_individual_with_education_level(self):
        """Test creating an individual with an education level."""
        individual = self._create_test_individual(
            education_level_id=self.education_secondary.id,
        )

        self.assertEqual(individual.education_level_id, self.education_secondary)

    def test_create_individual_with_head_of_household(self):
        """Test creating an individual marked as head of household."""
        individual = self._create_test_individual(
            is_head_of_household=True,
        )

        self.assertTrue(individual.is_head_of_household)

    def test_default_head_of_household_is_false(self):
        """Test that head of household defaults to False."""
        individual = self._create_test_individual()

        self.assertFalse(individual.is_head_of_household)

    def test_update_education_level(self):
        """Test updating an individual's education level."""
        individual = self._create_test_individual(
            education_level_id=self.education_primary.id,
        )

        individual.write({
            "education_level_id": self.education_tertiary.id,
        })

        self.assertEqual(individual.education_level_id, self.education_tertiary)
