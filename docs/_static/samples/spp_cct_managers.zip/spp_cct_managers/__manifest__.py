{
    "name": "OpenSPP CCT Program Managers",
    "summary": "Custom managers for conditional cash transfer programs: "
    "income-based eligibility, per-child entitlements, and quarterly cycles.",
    "category": "OpenSPP",
    "version": "19.0.1.0.0",
    "author": "OpenSPP",
    "website": "https://openspp.org",
    "license": "LGPL-3",
    "depends": [
        "spp_programs",
        "spp_security",
    ],
    "data": [
        "security/ir.model.access.csv",
        "views/eligibility_views.xml",
        "views/entitlement_views.xml",
        "views/cycle_views.xml",
    ],
    "installable": True,
}
