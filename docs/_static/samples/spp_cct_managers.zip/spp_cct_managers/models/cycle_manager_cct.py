# Part of OpenSPP. See LICENSE file for full copyright and licensing details.
"""CCT cycle manager — quarterly cycles aligned to Q1-Q4."""

import logging
from datetime import date

from dateutil.relativedelta import relativedelta

from odoo import fields, models

_logger = logging.getLogger(__name__)


QUARTER_START_MONTHS = {
    1: (1, 3),    # Q1: Jan-Mar
    2: (4, 6),    # Q2: Apr-Jun
    3: (7, 9),    # Q3: Jul-Sep
    4: (10, 12),  # Q4: Oct-Dec
}


class CCTCycleManager(models.Model):
    """Cycle manager for conditional cash transfer programs.

    Creates quarterly cycles aligned to calendar quarters (Q1-Q4).
    Inherits from spp.cycle.manager.default to get the full workflow
    surface (copy_beneficiaries_from_program, approval_definition_id,
    on_state_change, check_eligibility, approve_cycle, etc.) — we only
    override new_cycle to snap to calendar quarters.
    """

    _name = "spp.cycle.manager.cct"
    _inherit = ["spp.cycle.manager.default", "spp.manager.source.mixin"]
    _description = "CCT Cycle Manager (Quarterly)"

    is_auto_copy_beneficiaries = fields.Boolean(
        string="Auto-Copy Beneficiaries",
        default=True,
        help="Automatically copy enrolled beneficiaries from the program "
        "when a new cycle is created.",
    )

    def _get_quarter(self, d):
        """Return the quarter number (1-4) for a date."""
        return (d.month - 1) // 3 + 1

    def _get_quarter_dates(self, year, quarter):
        """Return (start_date, end_date) for a given quarter."""
        start_month, end_month = QUARTER_START_MONTHS[quarter]
        start_date = date(year, start_month, 1)
        end_date = date(year, end_month, 1) + relativedelta(months=1, days=-1)
        return start_date, end_date

    def new_cycle(self, name, new_start_date, sequence):
        """Create a new quarterly cycle aligned to calendar quarters."""
        quarter = self._get_quarter(new_start_date)
        year = new_start_date.year
        start_date, end_date = self._get_quarter_dates(year, quarter)

        cycle = self.env["spp.cycle"].create({
            "name": name or f"Q{quarter} {year}",
            "program_id": self.program_id.id,
            "start_date": start_date,
            "end_date": end_date,
            "sequence": sequence,
        })

        if self.is_auto_copy_beneficiaries:
            self.copy_beneficiaries_from_program(cycle)

        return cycle
