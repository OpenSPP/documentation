"""Tests for CCT program managers."""

from datetime import date

from dateutil.relativedelta import relativedelta

from odoo import fields
from odoo.tests import TransactionCase


class TestCCTEligibility(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        Partner = cls.env["res.partner"]

        # Create a household with one adult and one child
        cls.household = Partner.create({
            "name": "Test Household",
            "is_registrant": True,
            "is_group": True,
            "income": 5000.0,
        })
        cls.adult = Partner.create({
            "name": "Adult Member",
            "is_registrant": True,
            "is_group": False,
            "birthdate": date.today() - relativedelta(years=30),
        })
        cls.child = Partner.create({
            "name": "Child Member",
            "is_registrant": True,
            "is_group": False,
            "birthdate": date.today() - relativedelta(years=5),
        })
        cls.env["spp.group.membership"].create({
            "group": cls.household.id,
            "individual": cls.adult.id,
            "start_date": fields.Datetime.now(),
        })
        cls.env["spp.group.membership"].create({
            "group": cls.household.id,
            "individual": cls.child.id,
            "start_date": fields.Datetime.now(),
        })

        # Create eligibility manager
        cls.program = cls.env["spp.program"].create({
            "name": "Test CCT Program",
        })
        cls.eligibility = cls.env[
            "spp.program.membership.manager.cct"
        ].create({
            "name": "Test CCT Eligibility",
            "program_id": cls.program.id,
            "max_income": 10000.0,
            "child_max_age": 18,
        })

    def test_eligible_household_found(self):
        """Household with income under threshold and a child is eligible."""
        eligible_ids = self.eligibility._get_eligible_group_ids()
        self.assertIn(self.household.id, eligible_ids)

    def test_high_income_excluded(self):
        """Household with income above threshold is not eligible."""
        self.household.write({"income": 20000.0})
        eligible_ids = self.eligibility._get_eligible_group_ids()
        self.assertNotIn(self.household.id, eligible_ids)

    def test_no_children_excluded(self):
        """Household with only adults is not eligible."""
        # Age the child past the threshold
        self.child.write({
            "birthdate": date.today() - relativedelta(years=25),
        })
        eligible_ids = self.eligibility._get_eligible_group_ids()
        self.assertNotIn(self.household.id, eligible_ids)

    def test_import_no_duplicates(self):
        """Importing twice does not create duplicate memberships."""
        count_1 = self.eligibility.import_eligible_registrants()
        count_2 = self.eligibility.import_eligible_registrants()
        self.assertGreater(count_1, 0)
        self.assertEqual(count_2, 0, "Second import should find no new registrants")


class TestCCTEntitlement(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        Partner = cls.env["res.partner"]

        cls.household = Partner.create({
            "name": "Entitlement Household",
            "is_registrant": True,
            "is_group": True,
        })
        # Create 3 children
        for i in range(3):
            child = Partner.create({
                "name": f"Child {i+1}",
                "is_registrant": True,
                "is_group": False,
                "birthdate": date.today() - relativedelta(years=5 + i),
            })
            cls.env["spp.group.membership"].create({
                "group": cls.household.id,
                "individual": child.id,
                "start_date": fields.Datetime.now(),
            })

        cls.program = cls.env["spp.program"].create({
            "name": "Test CCT Program",
        })
        cls.entitlement_mgr = cls.env[
            "spp.program.entitlement.manager.cct"
        ].create({
            "name": "Test CCT Entitlement",
            "program_id": cls.program.id,
            "base_amount": 1000.0,
            "per_child_amount": 500.0,
            "max_children": 5,
            "child_max_age": 18,
        })

    def test_amount_calculation(self):
        """Amount = base + (per_child * children)."""
        amount = self.entitlement_mgr._calculate_amount(self.household)
        # 1000 + (500 * 3 children) = 2500
        self.assertEqual(amount, 2500.0)

    def test_max_children_cap(self):
        """Per-child top-up is capped at max_children."""
        self.entitlement_mgr.write({"max_children": 2})
        amount = self.entitlement_mgr._calculate_amount(self.household)
        # 1000 + (500 * 2 capped) = 2000
        self.assertEqual(amount, 2000.0)

    def test_no_cap_when_zero(self):
        """max_children=0 means no cap."""
        self.entitlement_mgr.write({"max_children": 0})
        amount = self.entitlement_mgr._calculate_amount(self.household)
        # 1000 + (500 * 3 children) = 2500
        self.assertEqual(amount, 2500.0)
