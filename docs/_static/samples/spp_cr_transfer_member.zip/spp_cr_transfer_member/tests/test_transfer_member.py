"""Tests for the Transfer Member CR type."""

from odoo import fields
from odoo.exceptions import UserError, ValidationError
from odoo.tests import TransactionCase


class TestTransferMember(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        Partner = cls.env["res.partner"]
        Membership = cls.env["spp.group.membership"]

        # Create source and target groups
        cls.source_group = Partner.create({
            "name": "Source Household",
            "is_registrant": True,
            "is_group": True,
        })
        cls.target_group = Partner.create({
            "name": "Target Household",
            "is_registrant": True,
            "is_group": True,
        })

        # Create a test individual and add to source group
        cls.individual = Partner.create({
            "name": "Test Person",
            "is_registrant": True,
            "is_group": False,
        })
        cls.membership = Membership.create({
            "group": cls.source_group.id,
            "individual": cls.individual.id,
            "start_date": fields.Datetime.now(),
        })

        # Look up or create the CR type
        cls.cr_type = cls.env["spp.change.request.type"].search(
            [("code", "=", "transfer_member")], limit=1
        )
        if not cls.cr_type:
            cls.cr_type = cls.env["spp.change.request.type"].create({
                "name": "Transfer Member",
                "code": "transfer_member",
                "target_type": "group",
                "detail_model": "spp.cr.detail.transfer_member",
                "apply_strategy": "custom",
                "apply_model": "spp.cr.apply.transfer_member",
            })

    def _create_cr(self, **detail_vals):
        """Helper: create a CR and populate its detail record."""
        cr = self.env["spp.change.request"].create({
            "request_type_id": self.cr_type.id,
            "registrant_id": self.source_group.id,
        })
        detail = cr.get_detail()
        detail.write(detail_vals)
        return cr

    def test_successful_transfer(self):
        """Applying an approved transfer ends old membership,
        creates new one."""
        cr = self._create_cr(
            membership_id=self.membership.id,
            target_group_id=self.target_group.id,
            transfer_reason="marriage",
            transfer_date=fields.Date.today(),
        )
        cr.approval_state = "approved"
        cr.action_apply()

        self.assertTrue(cr.is_applied)

        # Old membership is ended
        self.assertTrue(self.membership.ended_date)
        self.assertEqual(self.membership.status, "inactive")

        # New membership exists in target group
        new_membership = self.env["spp.group.membership"].search([
            ("group", "=", self.target_group.id),
            ("individual", "=", self.individual.id),
            ("status", "=", "active"),
        ])
        self.assertTrue(new_membership)

    def test_transfer_with_role(self):
        """Transferred member receives the assigned role."""
        individual = self.env["res.partner"].create({
            "name": "Role Test",
            "is_registrant": True,
            "is_group": False,
        })
        membership = self.env["spp.group.membership"].create({
            "group": self.source_group.id,
            "individual": individual.id,
            "start_date": fields.Datetime.now(),
        })

        role = self.env["spp.vocabulary.code"].search([
            ("vocabulary_id.namespace_uri", "=",
             "urn:openspp:vocab:group-membership-type"),
            ("code", "!=", "head"),
        ], limit=1)

        cr = self._create_cr(
            membership_id=membership.id,
            target_group_id=self.target_group.id,
            new_role_id=role.id if role else False,
            transfer_reason="relocation",
            transfer_date=fields.Date.today(),
        )
        cr.approval_state = "approved"
        cr.action_apply()

        new_membership = self.env["spp.group.membership"].search([
            ("group", "=", self.target_group.id),
            ("individual", "=", individual.id),
            ("status", "=", "active"),
        ])
        if role:
            self.assertIn(role, new_membership.membership_type_ids)

    def test_same_group_raises_validation_error(self):
        """Cannot set target group to the same as source group."""
        cr = self.env["spp.change.request"].create({
            "request_type_id": self.cr_type.id,
            "registrant_id": self.source_group.id,
        })
        detail = cr.get_detail()

        with self.assertRaises(ValidationError):
            detail.write({
                "target_group_id": self.source_group.id,
            })

    def test_duplicate_membership_raises_user_error(self):
        """Cannot transfer if individual is already in target group."""
        individual = self.env["res.partner"].create({
            "name": "Duplicate Test",
            "is_registrant": True,
            "is_group": False,
        })
        source_membership = self.env["spp.group.membership"].create({
            "group": self.source_group.id,
            "individual": individual.id,
            "start_date": fields.Datetime.now(),
        })
        self.env["spp.group.membership"].create({
            "group": self.target_group.id,
            "individual": individual.id,
            "start_date": fields.Datetime.now(),
        })

        cr = self._create_cr(
            membership_id=source_membership.id,
            target_group_id=self.target_group.id,
            transfer_reason="other",
            transfer_date=fields.Date.today(),
        )
        cr.approval_state = "approved"

        with self.assertRaises(UserError):
            cr.action_apply()

    def test_inactive_membership_raises_user_error(self):
        """Cannot transfer an already-ended membership."""
        individual = self.env["res.partner"].create({
            "name": "Inactive Test",
            "is_registrant": True,
            "is_group": False,
        })
        membership = self.env["spp.group.membership"].create({
            "group": self.source_group.id,
            "individual": individual.id,
            "start_date": fields.Datetime.now(),
            "ended_date": fields.Datetime.now(),
        })

        cr = self._create_cr(
            membership_id=membership.id,
            target_group_id=self.target_group.id,
            transfer_reason="other",
            transfer_date=fields.Date.today(),
        )
        cr.approval_state = "approved"

        with self.assertRaises(UserError):
            cr.action_apply()

    def test_available_individuals_excludes_head(self):
        """Head of household is not in the available individuals list."""
        head_kind = self.env["spp.vocabulary.code"].search([
            ("vocabulary_id.namespace_uri", "=",
             "urn:openspp:vocab:group-membership-type"),
            ("code", "=", "head"),
        ], limit=1)
        if not head_kind:
            return  # Skip if vocabulary not installed

        # Make the individual the head of household
        self.membership.write({
            "membership_type_ids": [(4, head_kind.id)],
        })

        cr = self.env["spp.change.request"].create({
            "request_type_id": self.cr_type.id,
            "registrant_id": self.source_group.id,
        })
        detail = cr.get_detail()

        self.assertNotIn(
            self.individual, detail.available_individual_ids,
            "Head of household should be excluded from available individuals",
        )

    def test_preview_returns_expected_structure(self):
        """Preview returns a dict describing the planned changes."""
        cr = self._create_cr(
            membership_id=self.membership.id,
            target_group_id=self.target_group.id,
            transfer_reason="marriage",
            transfer_date=fields.Date.today(),
        )

        preview = cr.action_preview_changes()

        self.assertEqual(preview["_action"], "transfer_member")
        self.assertIn("source_group", preview)
        self.assertIn("target_group", preview)
