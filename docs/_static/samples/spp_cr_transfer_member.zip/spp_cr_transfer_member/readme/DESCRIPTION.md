# CR Type: Transfer Member

Example custom change request type for transferring a member between groups (households).

This module accompanies the [Custom Change Request Types](https://docs.openspp.org/developer_guide/change_request_types/tutorial.html) developer guide. It demonstrates:

- A detail model with computed fields, onchange handlers, and validation constraints
- A custom apply strategy that ends one membership and creates another
- A form view with dynamic field filtering
- Security rules for the CR permission groups
- A test suite covering happy paths and error cases

## Usage

1. Install this module alongside `spp_change_request_v2`
2. Navigate to **Change Requests** and create a new request
3. Select **Transfer Member** as the type
4. Choose a source group, a member to transfer, and a target group
5. Submit, approve, and apply the change request
