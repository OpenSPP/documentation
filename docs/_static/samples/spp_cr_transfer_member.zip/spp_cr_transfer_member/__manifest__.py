{
    "name": "CR Type: Transfer Member",
    "summary": "Change request type to transfer a member between groups",
    "version": "17.0.1.0.0",
    "category": "OpenSPP",
    "author": "OpenSPP",
    "website": "https://openspp.org",
    "depends": ["spp_change_request_v2"],
    "data": [
        "security/ir.model.access.csv",
        "views/detail_transfer_member_views.xml",
        "data/cr_type.xml",
    ],
    "installable": True,
    "license": "LGPL-3",
}
