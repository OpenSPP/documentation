from odoo import api, fields, models
from odoo.exceptions import ValidationError


class SPPCRDetailTransferMember(models.Model):
    """Detail model for Transfer Member CR type.

    Captures the data needed to transfer an individual from one
    group (household) to another: the member to transfer, the
    target group, an optional role in the new group, and metadata
    like reason and date.
    """

    _name = "spp.cr.detail.transfer_member"
    _description = "CR Detail: Transfer Member"
    _inherit = ["spp.cr.detail.base", "mail.thread"]

    # Source group comes from the parent change request's registrant
    source_group_id = fields.Many2one(
        "res.partner",
        string="Source Group",
        related="change_request_id.registrant_id",
        store=True,
        readonly=True,
    )

    # Computed list of transferable members (excludes head of household)
    available_individual_ids = fields.Many2many(
        "res.partner",
        string="Available Individuals",
        compute="_compute_available_individuals",
        help="Active members excluding head of household",
    )

    individual_id = fields.Many2one(
        "res.partner",
        string="Member to Transfer",
        tracking=True,
        domain="[('is_group', '=', False), ('is_registrant', '=', True)]",
    )

    # Set automatically when individual_id changes
    membership_id = fields.Many2one(
        "spp.group.membership",
        string="Current Membership",
        readonly=True,
    )

    target_group_id = fields.Many2one(
        "res.partner",
        string="Target Group",
        tracking=True,
        domain="[('is_group', '=', True), ('is_registrant', '=', True),"
        " ('id', '!=', registrant_id)]",
    )

    new_role_id = fields.Many2one(
        "spp.vocabulary.code",
        string="Role in New Group",
        domain="[('vocabulary_id.namespace_uri', '=',"
        " 'urn:openspp:vocab:group-membership-type'),"
        " ('code', '!=', 'head')]",
        tracking=True,
    )

    transfer_reason = fields.Selection(
        [
            ("marriage", "Marriage"),
            ("separation", "Separation/Divorce"),
            ("relocation", "Relocation"),
            ("household_split", "Household Split"),
            ("correction", "Data Correction"),
            ("other", "Other"),
        ],
        string="Transfer Reason",
        tracking=True,
    )

    transfer_date = fields.Date(
        string="Transfer Date",
        default=fields.Date.today,
        tracking=True,
    )

    remarks = fields.Text(string="Remarks", tracking=True)

    # Computed display fields
    member_name = fields.Char(related="individual_id.name", readonly=True)
    source_group_name = fields.Char(related="source_group_id.name", readonly=True)
    target_group_name = fields.Char(related="target_group_id.name", readonly=True)

    @api.depends("change_request_id.registrant_id")
    def _compute_available_individuals(self):
        """Compute transferable members, excluding the head of household."""
        head_kind = self.env["spp.vocabulary.code"].get_code(
            "urn:openspp:vocab:group-membership-type", "head"
        )
        for rec in self:
            group = rec.change_request_id.registrant_id
            if not group:
                rec.available_individual_ids = self.env["res.partner"]
                continue

            memberships = self.env["spp.group.membership"].search([
                ("group", "=", group.id),
                ("status", "=", "active"),
            ])

            if head_kind:
                memberships = memberships.filtered(
                    lambda m: head_kind not in m.membership_type_ids
                )

            rec.available_individual_ids = memberships.mapped("individual")

    @api.onchange("individual_id")
    def _onchange_individual_id(self):
        """Look up the active membership when the user selects a member."""
        self.membership_id = False
        if self.individual_id and self.change_request_id.registrant_id:
            membership = self.env["spp.group.membership"].search([
                ("group", "=", self.change_request_id.registrant_id.id),
                ("individual", "=", self.individual_id.id),
                ("status", "=", "active"),
            ], limit=1)
            if membership:
                self.membership_id = membership

    @api.constrains("target_group_id", "source_group_id")
    def _check_different_groups(self):
        """Prevent transferring to the same group."""
        for rec in self:
            if rec.target_group_id and rec.source_group_id:
                if rec.target_group_id == rec.source_group_id:
                    raise ValidationError(
                        "Target group must be different from source group."
                    )
